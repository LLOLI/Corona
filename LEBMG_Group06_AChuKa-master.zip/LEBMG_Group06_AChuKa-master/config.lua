-- config.lua

application =
{
	content =
	{
		width = 320,
		height = 480,
		scale = "zoomEven" -- zoom to fill screen, possibly cropping edges
	},
}